import pygame
from random import randint
import os
from pickle import Unpickler
from pickle import Pickler
if not os.path.exists("score.txt"):
        new=True
        highscore=0
else:
    with open("score.txt", "rb") as lecture:
            new=False
            lecture = Unpickler(lecture)
            try:
                highscore=lecture.load()
            except:
                highscore=0
pygame.init()
keys = pygame.key.get_pressed()
charRight = [pygame.image.load('Game/R1.png'), pygame.image.load('Game/R2.png'), pygame.image.load('Game/R3.png'), pygame.image.load('Game/R4.png'), pygame.image.load('Game/R5.png'), pygame.image.load('Game/R6.png'), pygame.image.load('Game/R7.png'), pygame.image.load('Game/R8.png'), pygame.image.load('Game/R9.png')]
charLeft = [pygame.image.load('Game/L1.png'), pygame.image.load('Game/L2.png'), pygame.image.load('Game/L3.png'), pygame.image.load('Game/L4.png'), pygame.image.load('Game/L5.png'), pygame.image.load('Game/L6.png'), pygame.image.load('Game/L7.png'), pygame.image.load('Game/L8.png'), pygame.image.load('Game/L9.png')]
enemRight = [pygame.image.load('Game/R1E.png'), pygame.image.load('Game/R2E.png'), pygame.image.load('Game/R3E.png'), pygame.image.load('Game/R4E.png'), pygame.image.load('Game/R5E.png'), pygame.image.load('Game/R6E.png'), pygame.image.load('Game/R7E.png'), pygame.image.load('Game/R8E.png'), pygame.image.load('Game/R9E.png'), pygame.image.load('Game/R10E.png'), pygame.image.load('Game/R11E.png')]
enemLeft = [pygame.image.load('Game/L1E.png'), pygame.image.load('Game/L2E.png'), pygame.image.load('Game/L3E.png'), pygame.image.load('Game/L4E.png'), pygame.image.load('Game/L5E.png'), pygame.image.load('Game/L6E.png'), pygame.image.load('Game/L7E.png'), pygame.image.load('Game/L8E.png'), pygame.image.load('Game/L9E.png'),pygame.image.load('Game/L10E.png'),pygame.image.load('Game/L11E.png')]
window= pygame.display.set_mode((852,480))
bg = pygame.image.load("Game/bg.jpg")
stand=pygame.image.load("Game/standing.png")
rip=pygame.image.load("Game/rip.png")
boom=pygame.image.load("Game/boom.png")
font=pygame.font.SysFont("arial",25,True)
music=pygame.mixer.music.load("Game/135.mp3")
bull_sound=pygame.mixer.Sound("Game/bullet.wav")
hit_sound=pygame.mixer.Sound("Game/hit.wav")
pygame.mixer.music.play(-1)
yboom=yrip= 320
xboom=xrip=0
step=10
ping_enem=50
count_enemies=0
class enemy() :
    def __init__(self,y,ping):
        global rip,step,joueur,ping_enem,count_enemies
        count_enemies+=1
        self.y=y
        self.walk=0
        self.wall=False
        self.alive=True
        self.dead=False
        self.boom=False
        self.xrip=0
        self.yrip=0
        self.rip=pygame.image.load("Game/rip.png")
        self.next=[]
        if joueur.score < 25 :
            self.step=step+(joueur.score//5 * 2)
        else:
            self.step=20
        if joueur.score < 30:
            ping_enem=50-joueur.score
        else:
            ping_enem=20
        self.health=45
        if randint(0,1)==0 :
            self.x=0
            self.right=True
            self.left=False
            self.img=enemRight[0]
        else:
            self.x=852
            self.right=False
            self.left=True
            self.img=enemLeft[0]
        # self.display()
    def move(self):
        global joueur
        self.verif_cross()
        if self.right:
            self.walk+=1
            if self.x==850:
                self.walk+=1
                self.x=852
                # self.img=enemRight[self.walk%8]
            elif self.x==852:
                self.wall=True
            else:
                self.x+=self.step
                self.walk+=1
                # self.img=enemRight[self.walk%8]
            if self.x - joueur.x >= -30 and self.x - joueur.x < 0:
                if len(self.next) == 0:
                    self.next = [enemRight[8], enemRight[9], enemRight[10]]
                diff = self.x - joueur.x
                if diff < -20:
                    self.img = enemRight[10]
                elif diff >= -20 and diff < -10:
                    self.img = enemRight[9]
                else:
                    self.img = enemRight[8]
            elif self.x != 0:
                if len(self.next) == 0:
                    self.img = enemRight[self.walk % 8]
                else:
                    self.img = self.next[0]
                    self.next.pop(self.next.index(self.next[0]))
        if self.left:
                self.walk+=1
                if self.x==2:
                    self.walk+=1
                    self.x=0
                    # self.img=enemLeft[self.walk%8]
                elif self.x==0:
                    self.wall=True
                else:
                    self.x-=self.step
                    self.walk+=1
                    # self.img=enemLeft[self.walk%8]
                if self.x-joueur.x<=30 and self.x-joueur.x>0:
                    if len(self.next)==0:
                        self.next=[enemLeft[8],enemLeft[9],enemLeft[10]]
                    diff = self.x-joueur.x
                    if diff>20:
                        self.img=enemLeft[10]
                    elif diff<=20 and diff >10:
                        self.img=enemLeft[9]
                    else:
                        self.img=enemLeft[8]
                elif self.x!=0:
                    if len(self.next)==0:
                        self.img = enemLeft[self.walk % 8]
                    else:
                        self.img=self.next[0]
                        self.next.pop(self.next.index(self.next[0]))
        # if not self.wall:
        #     self.display()
    def verif_killed_boomed(self):
        global bulls,joueur
        for elem in bulls:
            if (elem[0].x >= self.x) and (elem[0].x<=self.x+64) and (elem[0].y>=self.y):
                self.health-=elem[0].attack
                hit_sound.play()
                if self.health==0:
                    self.dead=True
                    joueur.score+=1
                    if joueur.score%15==0:
                        joueur.health+=15
                    self.killed()
                else:
                    self.boom=True
                    self.boomed()
                bulls.pop(bulls.index(elem))
    def killed(self):
        global rip ,xrip , yrip
        self.xrip=self.x+15
        self.yrip=yrip
    def boomed(self):
        global boom , xboom , yboom
        self.xboom=self.x+15
        self.yboom=yboom
    def verif_cross(self):
      global  joueur
      if joueur.chance==0:
        if (self.right and joueur.left) or (self.left and joueur.left):
            if (joueur.x-self.x<20 and joueur.x-self.x>-15 and self.y-joueur.y<20) or (self.right and joueur.left and joueur.x-self.x<20 and joueur.x-self.x>-15 and not joueur.jump) :
                hit_sound.play()
                joueur.health-=15
                joueur.chance=5
                if joueur.health==0:
                    joueur.run=False
        if (self.left and joueur.right) or (self.right and joueur.right):
            if (self.x-joueur.x<20 and self.x-joueur.x>-15 and self.y-joueur.y<20) or (self.left and joueur.right and self.x-joueur.x<20 and self.x-joueur.x>-15 and not joueur.jump)  :
                hit_sound.play()
                joueur.health-=15
                joueur.chance=5
                if joueur.health==0:
                    joueur.run=False
      else:
          joueur.chance-=1

class player() :
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.run=True
        self.jump=False
        self.right=False
        self.left=True
        self.move=0
        self.chance = 0
        self.cpt=0
        self.score=0
        self.health=45
        self.img=pygame.image.load("Game/standing.png")
    def verif_quit(self):
        for eve in pygame.event.get():
            if eve.type == pygame.QUIT:
                self.run = False
    def verif_jump(self):
        keys = pygame.key.get_pressed()
        if not self.jump:
            if keys[pygame.K_UP]:
                self.cpt = 7
                self.jump = True
        else:
            if self.cpt > 0:
                self.y -= self.cpt ** 2 * 0.5
            else:
                self.y += self.cpt ** 2 * 0.5
            self.cpt -= 1
            if self.cpt == -8:
                self.cpt = 7
                self.jump = False
    def movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            if not self.jump:
                self.x -= 20
            else:
                self.x -= 12
            if not self.left:
                self.move = 0
            self.left = True
            self.right = False
            self.move += 1
        if keys[pygame.K_RIGHT]:
            if not self.jump:
                self.x += 20
            else:
                self.x += 12
            if not self.right:
                self.move = 0
            self.left = False
            self.right = True
            self.move += 1
        self.verif_jump()
    def lunch(self):
        global bg , charLeft,charRight
          # fill the screen with black
        if self.right:
            self.img = charRight[self.move % 9]
        if self.left:
            self.img = charLeft[self.move % 9]
        # window.blit(self.img, (self.x % 852, self.y % 480))  # draw rectangle on position x,y and width=60 , height=60 , color=(120,120,120)
        # pygame.display.update()  # refresh the screen
class bullet(object):
     def __init__(self,player):
         self.shooted = True
         self.attack=15
         if player.left:
             self.x = (player.x + 18) % 852
             self.y = (player.y + 25) % 480
             self.left = True
             self.right = False
         else:
             self.x = (player.x + 45) % 852
             self.y = (player.y + 25) % 480
             self.right = True
             self.left = False
         self.img=pygame.image.load("Game/bullet.png")
     def move_bullet(self):
         self.x=int(self.x)
         self.y=int(self.y)
         if self.shooted:
             # window.blit(self.img, (self.x % 852, self.y % 480))
             # pygame.display.update()
             if self.right:
                 self.x += 25
             if self.left:
                 self.x -= 25
             if self.x > 852 or self.x < 0:
                 for elem in bulls:
                     if elem[0]==self:
                        bulls.pop(bulls.index(elem))
                        break
     def create_bullet(self,player,bulls):
         global ping
         bulls.append((bullet(player),ping))
         bull_sound.play()
     def shoot(self,player,bulls):
         keys=pygame.key.get_pressed()
         global ping
         if keys[pygame.K_SPACE] and len(bulls)<6  :
             if len(bulls)==0:
                self.create_bullet(player,bulls)
             else:
                 if ping - bulls[len(bulls) - 1][1] > 6:
                     self.create_bullet(player, bulls)
def draw_health(pers):
    if pers.right:
        pygame.draw.rect(window, (7, 246, 31), (pers.x + 7, pers.y - 10, pers.health, 8))
        if pers.health < 45:
            pygame.draw.rect(window, (255, 9, 9), (pers.x + 7 + pers.health, pers.y - 10, 45 - pers.health, 8))
    else:
        pygame.draw.rect(window, (7, 246, 31), (pers.x + 7, pers.y - 10, pers.health, 8))
        if pers.health < 45:
            pygame.draw.rect(window, (255, 9, 9), (pers.x + 7 + pers.health, pers.y - 10, 45 - pers.health, 8))

def display():
    global window , bg , joueur,bulls,enemies,rip,booms
    window.blit(bg,(0,0))
    if joueur.right:
        joueur.img = charRight[joueur.move % 9]
    if joueur.left:
        joueur.img = charLeft[joueur.move %9]
    window.blit(joueur.img, (joueur.x % 852, joueur.y % 480))
    draw_health(joueur)
    for elem in bulls:
        window.blit(elem[0].img, (elem[0].x % 852, elem[0].y % 480))
    for elema in enemies :
        window.blit(elema.img, (elema.x, elema.y))
        draw_health(elema)
        elema.verif_killed_boomed()
        if elema.boom:
            coord=[elema.xboom,elema.yboom,3]
            booms.append(coord)
            elema.boom=False
        if elema.dead:
            coord=[elema.xrip,elema.yrip,3]
            rips.append(coord)
            elema.wall=True
    for coord in rips :
            if coord[2]!=0:
               window.blit(rip,(coord[0],coord[1]))
               coord[2]-=1
            else:
                rips.pop(rips.index(coord))
    for coord in booms :
            if coord[2]!=0:
               window.blit(boom,(coord[0],coord[1]))
               coord[2]-=1
            else:
                booms.pop(booms.index(coord))
    text = font.render("Your Score : " + str(joueur.score), 1, (0, 0, 0))
    window.blit(text, (670, 15))
    text = font.render("High Score : " + str(highscore), 1, (0, 0, 0))
    window.blit(text, (670, 45))
    text = font.render("Your Health : " + str(joueur.health*100//45)+"%", 1, (0, 0, 0))
    window.blit(text,(10,15))
    pygame.display.update()

pygame.display.set_caption("Sid Ahmed's game")
joueur=player(200,350)
bulls=[]
enemies=[]
rips=[]
booms=[]
ping=0
rip_ping=0
window.blit(bg, (0, 0))
while joueur.run :
    window.blit(bg, (0, 0))
    ping+=1
    pygame.time.delay(30)
    joueur.verif_quit()
    bull=bullet(joueur)
    bull.shoot(joueur,bulls)
    for elem in bulls :
        elem[0].move_bullet()
    if ping%ping_enem==0:
        enemies.append(enemy(355,ping))
    for enem in enemies:
        if not enem.wall:
            enem.move()
        else:
            enemies.pop(enemies.index(enem))
    joueur.movement()
    display()
font=pygame.font.SysFont("arial",50,True)
if new:
    text = font.render("I hope you like your first experience", 1, (0, 255, 0))
    window.blit(text, (100, 150))
text = font.render("Your Current Score : " + str(joueur.score), 1, (0, 0, 0))
window.blit(text, (200,200 ))
if joueur.score >= highscore:
    text = font.render("You Have the highest Score !!!",1,(255,0,0))
    window.blit(text, (200, 250))
    with open("score.txt","wb") as ecriture:
        Pickler(ecriture).dump(joueur.score)
else:
    text=font.render("High Score : " + str(highscore),1,(0,0,0))
    window.blit(text,(200,250))
pygame.display.update()
pygame.time.delay(5000)
pygame.quit()
# import pygame
# pygame.init()
# font=pygame.font.SysFont("microsoftyibaiti",25,True)
# text = font.render("hello world",1,(0,0,0))
# window= pygame.display.set_mode((852,480))
# window.blit(text,(10,10))
