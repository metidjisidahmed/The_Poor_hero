import pygame
import random
import os
import pickle
if not os.path.exists("score.txt"):
        new=True
        highscore=0
else:
    with open("score.txt", "rb") as lecture:
            new=False
            lecture = pickle.Unpickler(lecture)
            try:
                highscore=lecture.load()
            except:
                highscore=0
pygame.init()
keys = pygame.key.get_pressed()
charRight = [pygame.image.load('Game/R1.png'), pygame.image.load('Game/R2.png'), pygame.image.load('Game/R3.png'), pygame.image.load('Game/R4.png'), pygame.image.load('Game/R5.png'), pygame.image.load('Game/R6.png'), pygame.image.load('Game/R7.png'), pygame.image.load('Game/R8.png'), pygame.image.load('Game/R9.png')]
charLeft = [pygame.image.load('Game/L1.png'), pygame.image.load('Game/L2.png'), pygame.image.load('Game/L3.png'), pygame.image.load('Game/L4.png'), pygame.image.load('Game/L5.png'), pygame.image.load('Game/L6.png'), pygame.image.load('Game/L7.png'), pygame.image.load('Game/L8.png'), pygame.image.load('Game/L9.png')]
enemRight = [pygame.image.load('Game/R1E.png'), pygame.image.load('Game/R2E.png'), pygame.image.load('Game/R3E.png'), pygame.image.load('Game/R4E.png'), pygame.image.load('Game/R5E.png'), pygame.image.load('Game/R6E.png'), pygame.image.load('Game/R7E.png'), pygame.image.load('Game/R8E.png'), pygame.image.load('Game/R9E.png'), pygame.image.load('Game/R10E.png'), pygame.image.load('Game/R11E.png')]
enemLeft = [pygame.image.load('Game/L1E.png'), pygame.image.load('Game/L2E.png'), pygame.image.load('Game/L3E.png'), pygame.image.load('Game/L4E.png'), pygame.image.load('Game/L5E.png'), pygame.image.load('Game/L6E.png'), pygame.image.load('Game/L7E.png'), pygame.image.load('Game/L8E.png'), pygame.image.load('Game/L9E.png'),pygame.image.load('Game/L10E.png'),pygame.image.load('Game/L11E.png')]
birdLeft=[pygame.image.load("Game/BL1.png"),pygame.image.load("Game/BL1.png"),pygame.image.load("Game/BL1.png"),pygame.image.load("Game/BL2.png"),pygame.image.load("Game/BL2.png"),pygame.image.load("Game/BL2.png"),pygame.image.load("Game/BL3.png"),pygame.image.load("Game/BL3.png"),pygame.image.load("Game/BL3.png"),pygame.image.load("Game/BL4.png"),pygame.image.load("Game/BL4.png"),pygame.image.load("Game/BL4.png"),pygame.image.load("Game/BL5.png"),pygame.image.load("Game/BL5.png"),pygame.image.load("Game/BL5.png"),pygame.image.load("Game/BL6.png"),pygame.image.load("Game/BL6.png"),pygame.image.load("Game/BL6.png"),pygame.image.load("Game/BL7.png"),pygame.image.load("Game/BL7.png"),pygame.image.load("Game/BL7.png")]
birdRight=[pygame.image.load("Game/BR1.png"),pygame.image.load("Game/BR1.png"),pygame.image.load("Game/BR1.png"),pygame.image.load("Game/BR2.png"),pygame.image.load("Game/BR2.png"),pygame.image.load("Game/BR2.png"),pygame.image.load("Game/BR3.png"),pygame.image.load("Game/BR3.png"),pygame.image.load("Game/BR3.png"),pygame.image.load("Game/BR4.png"),pygame.image.load("Game/BR4.png"),pygame.image.load("Game/BR4.png"),pygame.image.load("Game/BR5.png"),pygame.image.load("Game/BR5.png"),pygame.image.load("Game/BR5.png"),pygame.image.load("Game/BR6.png"),pygame.image.load("Game/BR6.png"),pygame.image.load("Game/BR6.png"),pygame.image.load("Game/BR7.png"),pygame.image.load("Game/BR7.png"),pygame.image.load("Game/BR7.png")]
bomb_pic=[pygame.image.load("Game/B11.png"),pygame.image.load("Game/B33.png"),pygame.image.load("Game/B33.png"),pygame.image.load("Game/B44.png"),pygame.image.load("Game/B44.png"),pygame.image.load("Game/B55.png"),pygame.image.load("Game/B55.png"),pygame.image.load("Game/B66.png"),pygame.image.load("Game/B66.png")]
levels=dict()
levels["speed goblin"]=[8,12,20,12,14,12,15,12,12]
levels["ping goblin"]=[70,35,60,50,60,60,40,25,25]
levels["damage goblin"]=[20,20,15,20,15,20,15,30,10]
levels["speed bird"]=[0,0,0,15,10,15,30,10,10]
levels["ping bird"]=[0,0,0,80,60,40,100,200,70]
levels["speed bomb"]=[0,0,0,20,20,10,10,30,8]
levels["ping bomb"]=[0,0,0,20,20,17,15,7,18]
levels["damage bomb"]=[0,0,0,30,25,20,20,12,25]
levels["bonus health"]=[20,20,20,30,20,40,80,70,60]
levels["level"]=[5,10,20,30,40,50,60,70,80]
window= pygame.display.set_mode((852,480))
bg = pygame.image.load("Game/bg.jpg")
stand=pygame.image.load("Game/standing.png")
rip=pygame.image.load("Game/rip.png")
boom=pygame.image.load("Game/boom.png")
fall_sound=pygame.mixer.Sound("Game/fall0.wav")
boom_sound=pygame.mixer.Sound("Game/boom.wav")
font=pygame.font.SysFont("arial",25,True)
# music=pygame.mixer.music.load("Game/135.mp3")
bull_sound=pygame.mixer.Sound("Game/shootor.wav")
hit_sound=pygame.mixer.Sound("Game/hit.wav")
# pygame.mixer.music.play(-1)
walk_sound=[pygame.mixer.Sound("Game/walk1.wav"),pygame.mixer.Sound("Game/walk2.wav")]
jump_sound=pygame.mixer.Sound("Game/jump.wav")
yboom=yrip= 320
xboom=xrip=0
speed=10

count_enemies=0
class enemy() :
    def __init__(self,y,ping):
        global rip,speed,joueur,ping_enem,count_enemies
        count_enemies+=1
        self.y=y
        self.walk=0
        self.wall=False
        self.alive=True
        self.dead=False
        self.boom=False
        self.xrip=0
        self.yrip=0
        self.rip=pygame.image.load("Game/rip.png")
        self.next=[]
        self.speed=levels["speed goblin"][joueur.level()]
        # if joueur.score < 30:
        #     ping_enem=50-joueur.score
        # else:
        #     ping_enem=20
        self.health=100
        if random.randint(0,1)==0 :
            self.x=0
            self.right=True
            self.left=False
            self.img=enemRight[0]
        else:
            self.x=852
            self.right=False
            self.left=True
            self.img=enemLeft[0]
        # self.display()
    def move(self):
        global joueur
        self.verif_cross()
        if self.right:
            self.walk+=1
            if self.x==850:
                self.walk+=1
                self.x=852
                # self.img=enemRight[self.walk%8]
            elif self.x==852:
                self.wall=True
            else:
                self.x+=self.speed
                self.walk+=1
                # self.img=enemRight[self.walk%8]
            if self.x - joueur.x >= -30 and self.x - joueur.x < 0:
                if len(self.next) == 0:
                    self.next = [enemRight[8], enemRight[9], enemRight[10]]
                diff = self.x - joueur.x
                if diff < -20:
                    self.img = enemRight[10]
                elif diff >= -20 and diff < -10:
                    self.img = enemRight[9]
                else:
                    self.img = enemRight[8]
            elif self.x != 0:
                if len(self.next) == 0:
                    self.img = enemRight[self.walk % 8]
                else:
                    self.img = self.next[0]
                    self.next.pop(self.next.index(self.next[0]))
        if self.left:
                self.walk+=1
                if self.x==2:
                    self.walk+=1
                    self.x=0
                    # self.img=enemLeft[self.walk%8]
                elif self.x==0:
                    self.wall=True
                else:
                    self.x-=self.speed
                    self.walk+=1
                    # self.img=enemLeft[self.walk%8]
                if self.x-joueur.x<=30 and self.x-joueur.x>0:
                    if len(self.next)==0:
                        self.next=[enemLeft[8],enemLeft[9],enemLeft[10]]
                    diff = self.x-joueur.x
                    if diff>20:
                        self.img=enemLeft[10]
                    elif diff<=20 and diff >10:
                        self.img=enemLeft[9]
                    else:
                        self.img=enemLeft[8]
                elif self.x!=0:
                    if len(self.next)==0:
                        self.img = enemLeft[self.walk % 8]
                    else:
                        self.img=self.next[0]
                        self.next.pop(self.next.index(self.next[0]))
        # if not self.wall:
        #     self.display()
    def verif_killed_boomed(self):
        global bulls,joueur
        for elem in bulls:
            if (elem[0].x >= self.x) and (elem[0].x<=self.x+64) and (elem[0].y>=self.y):
                self.health-=33
                if self.health==1:
                    self.dead=True
                    joueur.score+=1
                    if joueur.score%10==0:
                        joueur.health+=levels["bonus health"][joueur.level()]
                        levels["bonus health"][joueur.level()]=0
                    self.killed()
                else:
                    self.boom=True
                    self.boomed()
                bulls.pop(bulls.index(elem))
    def killed(self):
        global rip ,xrip , yrip
        self.xrip=self.x+15
        self.yrip=yrip
    def boomed(self):
        global boom , xboom , yboom
        self.xboom=self.x+15
        self.yboom=yboom
    def verif_cross(self):
      global  joueur
      if joueur.chance==0:
        if (self.right and joueur.left) or (self.left and joueur.left):
            if (joueur.x-self.x<20 and joueur.x-self.x>-15 and self.y-joueur.y<20) or (self.right and joueur.left and joueur.x-self.x<20 and joueur.x-self.x>-15 and not joueur.jump) :
                hit_sound.play()
                joueur.health-=levels["damage goblin"][joueur.level()]
                joueur.chance=5
                if joueur.health<=0:
                    joueur.run=False
        if (self.left and joueur.right) or (self.right and joueur.right):
            if (self.x-joueur.x<20 and self.x-joueur.x>-15 and self.y-joueur.y<20) or (self.left and joueur.right and self.x-joueur.x<20 and self.x-joueur.x>-15 and not joueur.jump)  :
                hit_sound.play()
                joueur.health-=levels["damage goblin"][joueur.level()]
                joueur.chance=5
                if joueur.health<=0:
                    joueur.run=False
      else:
          joueur.chance-=1
class bird() :
    def __init__(self,y):
        self.y=y
        self.speed=10
        self.move=0
        self.left=False
        self.right=False
        if random.randint(0,1)==0:
            self.left=False
            self.right=True
            self.x=0
            self.img=birdRight[0]
        else:
            self.x=852
            self.left=True
            self.right=False
            self.img=birdLeft[0]
    def move_it(self):
        global birds
        if self.right and not self.left:
            if self.x==852:
                birds.pop(birds.index(self))
            elif 852-self.x<self.speed:
                self.x=852
                self.move+=1
                self.img = birdRight[self.move%21]
            else:
                self.move+=1
                self.x+=self.speed
                self.img = birdRight[self.move%21]
        if self.left and not self.right:
            if self.x==0:
                birds.pop(birds.index(self))
            elif self.x<self.speed:
                self.x=0
                self.move+=1
                self.img=birdLeft[self.move%21]
            else:
                self.move+=1
                self.x-=self.speed
                self.img = birdLeft[self.move % 21]
    # def create_bird(self,y):
    #     global birds
    #     birds.append(bird(y))

class bomb():
    def __init__(self,zawach):
        global bomb_pic,bombs,ping
        self.x=zawach.x+32
        self.y=zawach.y+32
        self.explode=False
        self.floor=373
        self.speed=8
        self.cpt=0
        self.img=bomb_pic[0]
        self.steps=0
        self.last=0
        self.sizex=29
        self.sizey=40
        self.end=False
    def move(self):
      if not self.explode:
            self.steps+=1
            if self.floor-self.y>self.speed:
                self.y+=self.speed
            elif self.y!=self.floor:
                self.y=self.floor
            else:
                boom_sound.play()
                self.explode=True

      else:
            if self.cpt>3:
                self.y -= 29
            if self.cpt>2:
                self.y=self.floor-50
            self.cpt+=1
            try :
                self.img=bomb_pic[self.cpt]
            except:
                bombs.pop(bombs.index(self))
    def verif_hurt(self):
        if self.cpt==0:
            self.sizex=29
            self.sizey=40
        elif self.cpt<=2:
            self.sizex=47
            self.sizey=45
        elif self.cpt<=4:
            self.sizex=71
            self.sizey=63
        elif self.cpt<=6:
            self.sizex=87
            self.sizey=79
        else:
            self.end=True
        if not self.end:
                if ((self.y + self.sizey >= joueur.y and self.y + self.sizey <= joueur.y + 47) or (self.y >= joueur.y and self.y  <= joueur.y + 47)) and ((self.x + self.sizex > joueur.x and self.x + self.sizex < joueur.x + 24) or (self.x >= joueur.x and self.x <= joueur.x + 24)):
                    if self.last==0 or self.steps>self.last+3:
                        joueur.health -= levels["damage bomb"][joueur.level()]
                        hit_sound.play()
                        self.last=self.steps
                        if joueur.health <= 0:
                            joueur.run = False
                    if self.cpt!=0:
                        self.end=True

class player() :
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.run=True
        self.jump=False
        self.right=False
        self.left=True
        self.move=0
        self.chance = 0
        self.cpt=0
        self.score=0
        self.health=100
        self.max=False
        self.img=pygame.image.load("Game/standing.png")
    def verif_quit(self):
        for eve in pygame.event.get():
            if eve.type == pygame.QUIT:
                self.run = False
    def verif_jump(self):
        keys = pygame.key.get_pressed()
        if not self.jump:
            if keys[pygame.K_UP]:
                self.cpt = 7
                self.jump = True
                jump_sound.play()
        else:
            if self.cpt > 0:
                self.y -= self.cpt ** 2 * 0.5
            else:
                self.y += self.cpt ** 2 * 0.5
            self.cpt -= 1
            if self.cpt == -8:
                self.cpt = 7
                self.jump = False
    def movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            if not self.jump:
                self.x -= 17
                walk_sound[self.move%2].play()
            else:
                self.x -= 10
            if not self.left:
                self.move = 0
            self.left = True
            self.right = False
            self.move += 1
        if keys[pygame.K_RIGHT]:
            if not self.jump:
                self.x += 17
                walk_sound[self.move % 2].play()
            else:
                self.x += 10
            if not self.right:
                self.move = 0
            self.left = False
            self.right = True
            self.move += 1
        self.verif_jump()
    def level(self):
        global levels
        cpt=0
        while joueur.score>levels["level"][cpt]:
            if cpt !=8:
                cpt+=1
            else:
                break
        return cpt

    def lunch(self):
        global bg , charLeft,charRight
          # fill the screen with black
        if self.right:
            self.img = charRight[self.move % 9]
        if self.left:
            self.img = charLeft[self.move % 9]
        # window.blit(self.img, (self.x % 852, self.y % 480))  # draw rectangle on position x,y and width=60 , height=60 , color=(120,120,120)
        # pygame.display.update()  # refresh the screen
class bullet(object):
     def __init__(self,player):
         self.shooted = True
         self.attack=15
         if player.left:
             self.x = (player.x) % 852
             self.y = (player.y + 8) % 480
             self.left = True
             self.right = False
         else:
             self.x = (player.x + 20) % 852
             self.y = (player.y + 8) % 480
             self.right = True
             self.left = False
         self.img=pygame.image.load("Game/bullet.png")
     def move_bullet(self):
         self.x=int(self.x)
         self.y=int(self.y)
         if self.shooted:
             # window.blit(self.img, (self.x % 852, self.y % 480))
             # pygame.display.update()
             if self.right:
                 self.x += 25
             if self.left:
                 self.x -= 25
             if self.x > 852 or self.x < 0:
                 for elem in bulls:
                     if elem[0]==self:
                        bulls.pop(bulls.index(elem))
                        break

     def create_bullet(self,player,bulls):
         global ping
         bulls.append((bullet(player),ping))
         bull_sound.play()
     def shoot(self,player,bulls):
         keys=pygame.key.get_pressed()
         global ping
         if keys[pygame.K_SPACE] and len(bulls)<6  :
             if len(bulls)==0:
                self.create_bullet(player,bulls)
             else:
                 if ping - bulls[len(bulls) - 1][1] > 6:
                     self.create_bullet(player, bulls)
def draw_health(pers):
    if pers.right:
        pygame.draw.rect(window, (7, 246, 31), (pers.x -10, pers.y - 18, pers.health//2, 8))
        if pers.health < 100:
            pygame.draw.rect(window, (255, 9, 9), (pers.x -10 + pers.health//2, pers.y - 18, (100 - pers.health)//2, 8))
    else:
        pygame.draw.rect(window, (7, 246, 31), (pers.x - 10, pers.y - 18, pers.health//2, 8))
        if pers.health < 100:
            pygame.draw.rect(window, (255, 9, 9), (pers.x -10 + pers.health//2, pers.y - 18, (100 - pers.health)//2, 8))

def display():
    global window , bg , joueur,bulls,enemies,rip,booms
    window.blit(bg,(0,0))
    if joueur.right:
        joueur.img = charRight[joueur.move % 9]
    if joueur.left:
        joueur.img = charLeft[joueur.move %9]
    window.blit(joueur.img, (joueur.x % 852, joueur.y % 480))
    draw_health(joueur)
    for elem in bulls:
        window.blit(elem[0].img, (elem[0].x % 852, elem[0].y % 480))
    for elema in enemies :
        window.blit(elema.img, (elema.x, elema.y))
        draw_health(elema)
        elema.verif_killed_boomed()
        if elema.boom:
            coord=[elema.xboom,elema.yboom,3]
            booms.append(coord)
            elema.boom=False
        if elema.dead:
            coord=[elema.xrip,elema.yrip,3]
            rips.append(coord)
            elema.wall=True
    for elema in birds:
        window.blit(elema.img,(elema.x,elema.y))
    for elem in bombs:
        window.blit(elem.img, (elem.x, elem.y))
    for coord in rips :
            if coord[2]!=0:
               window.blit(rip,(coord[0],coord[1]))
               coord[2]-=1
            else:
                rips.pop(rips.index(coord))
    for coord in booms :
            if coord[2]!=0:
               window.blit(boom,(coord[0],coord[1]))
               coord[2]-=1
            else:
                booms.pop(booms.index(coord))
    text = font.render("Your Score : " + str(joueur.score), 1, (0, 0, 0))
    window.blit(text, (670, 15))
    text = font.render("High Score : " + str(highscore), 1, (0, 0, 0))
    window.blit(text, (670, 45))
    text = font.render("Your Health : " + str(joueur.health)+"%", 1, (0, 0, 0))
    window.blit(text,(10,15))
    if joueur.level()!=8:
        text = font.render("Your Level : " + str(joueur.level() +1), 1, (0, 0, 0))
    else:
        text = font.render("Your Level : " + "MAX", 1, (0, 0, 0))
    window.blit(text,(10,45))
    text= font.render("Metidji Sid Ahmed ©" , 1 , (255,0,0))
    window.blit(text,(10,440))
    pygame.display.update()
#floor : y = 350 + 64  - 40 = 374
#bomb init_pos= 70+32=102
#bomb step : 20
pygame.display.set_caption("Sid Ahmed's game")
joueur=player(200,366)
bulls=[]
enemies=[]
rips=[]
booms=[]
birds=[]
bombs=[]
ping=0
rip_ping=0
window.blit(bg, (0, 0))
while joueur.run :
    ping_enem = levels["ping goblin"][joueur.level()]
    ping_bird = levels["ping bird"][joueur.level()]
    ping_bomb = levels["ping bomb"][joueur.level()]
    window.blit(bg, (0, 0))
    ping+=1
    pygame.time.delay(30)
    joueur.verif_quit()
    bull=bullet(joueur)
    bull.shoot(joueur,bulls)
    for elem in bulls :
        elem[0].move_bullet()
    for elem in birds:
        elem.move_it()
    if ping%ping_enem==0:
        enemies.append(enemy(355,ping))
    if ping_bird!=0:
        if ping%ping_bird==0:
            birds.append(bird(70))
    if ping_bomb!=0:
        if ping%ping_bomb==0 and len(birds):
            for elem in birds:
                bombs.append(bomb(elem))
                fall_sound.play()
    for enem in enemies:
        if not enem.wall:
            enem.move()
        else:
            enemies.pop(enemies.index(enem))
    for elem in bombs:
        elem.verif_hurt()
        elem.move()
    if joueur.run:
        joueur.movement()
    display()
font=pygame.font.SysFont("arial",50,True)
if new:
    text = font.render("I hope you like your first experience", 1, (0, 255, 0))
    window.blit(text, (100, 150))
text = font.render("Your Current Score : " + str(joueur.score), 1, (0, 0, 0))
window.blit(text, (200,200 ))
if joueur.score >= highscore:
    text = font.render("You Have the highest Score !!!",1,(255,0,0))
    window.blit(text, (200, 250))
    with open("score.txt","wb") as ecriture:
        pickle.Pickler(ecriture).dump(joueur.score)
else:
    text=font.render("High Score : " + str(highscore),1,(0,0,0))
    window.blit(text,(200,250))
pygame.display.update()
pygame.time.delay(5000)
pygame.quit()

